<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif, sans-serif;
      font-weight: 100;
      font-weight: 100;
      


      margin: 0;
      padding: 0;
      display: flex;
      background-color: #f4f4f9;
    }

    .sidebar {
      width: 20%;
      background: linear-gradient(180deg, #333, #555);
      color: white;
      padding: 20px;
      height: 100vh;
      box-shadow: 2px 0 5px rgba(189, 35, 35, 0.1);
    }

    .sidebar h2 {
      font-size: 24px;
      margin-bottom: 20px;
      text-align: center;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin: 15px 0;
      font-size: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 10px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .sidebar ul li:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
    }

    .submenu {
      display: none;
      margin-left: 20px;
    }

    .submenu li {
      margin: 10px 0;
      font-size: 16px;
    }

    .main-content {
      width: 80%;
      padding: 20px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .header input[type="text"] {
      padding: 10px;
      font-size: 16px;
      width: 350px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header button {
      padding: 10px 20px;
      font-size: 16px;
      color: white;
      background-color: #B49C73;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .header button:hover {
      background-color: #B49C73;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .card {
      background: linear-gradient(145deg, #242222, #e6e6e6);
      border-radius: 10px;
      padding: 20px;
      
      text-align: center;
      box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1), -5px -5px 10px rgba(255, 255, 255, 0.5);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .card button {
      width: 100%;
      height: 70px;
      font-size: 20px;
      font-weight: bold;
      background: linear-gradient(90deg, #B49C73, #B49C73);
      color: white;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .card button:hover {
      background: linear-gradient(90deg, #B49C73, #B49C73);
    }

    .arrow {
      transition: transform 0.3s;
    }

    .sidebar ul li.open .arrow {
      transform: rotate(180deg);
    }
  </style>
</head>
<link href="css/style.css" rel="stylesheet">
<body>
  <div class="sidebar">
    <h2 class="card"> Admin Dashboard  </h2>
    <ul>
      <!-- Manage Advocate -->
      <li onclick="toggleSubmenu('manage-advocate')">
        <span>Manage Advocate</span>
        <span class="arrow">&#9660;</span>
      </li>
      <ul id="manage-advocate" class="submenu">
        <li><a href="advocateReg.php">Add</a></li>
        <li><a href="advRegTable.php">Delete</a></li>
        <li><a href="advRegTable.php">Update</a></li>
      </ul>

      <!-- Case Category -->
      <li onclick="toggleSubmenu('case-category')">
        <span>Case Category</span>
        <span class="arrow">&#9660;</span>
      </li>
      <ul id="case-category" class="submenu">
        <li><a href="civil_display.php">Civil</a></li>
        <li><a href="corporate.php">Corporate</a></li>
        <li><a href="family_dis.php">Family</a></li>
        <li><a href="criminal.php">Criminal</a></li>
        <li><a href="Business.php">Business</a></li>
      </ul>

      <!-- Case Details -->
      <li onclick="toggleSubmenu('case-details')">
        <span>Case Details</span>
        <span class="arrow">&#9660;</span>
      </li>
      <ul id="case-details" class="submenu">
        <li><a href="#">Case 1</a></li>
        <li><a href="#">Case 2</a></li>
        <li><a href="#">Case 3</a></li>
      </ul>
    </ul>
  </div>
  <div class="main-content">
    <div class="header">
      <input type="text" placeholder="Search">
      <button>Admin</button>
      <div class="admin-menu">
        
     
      <a href="login.php" class="btn btn-primary mr-3 d-none d-lg-block">LOGOUT</a>
      </div>
    </div>
    
    <?php
    include("config.php");
    error_reporting(0);
    $query="SELECT * FROM client_reg WHERE Service_type='corporate' ";
    $data=mysqli_query($con,$query);
    $totle=mysqli_num_rows($data);
    

    if($totle!=0){
        ?>
        <table><tr>
            <td>Client Name</td>
            <td>Gender</td>
            <td>Email</td>
            <td>Mobile No</td>
            <td>service type</td>
            </tr>
            <?php
            while($result=mysqli_fetch_assoc($data))
            {
                echo"<tr>
                <td>".$result['clientname']."</td>
                <td>".$result['gender']."</td>
                <td>".$result['Email_id']."</td>
                <td>".$result['Mobile_no']."</td>
                <td>".$result['Service_type']."</td>
                </tr>";
            }
        }
        else{
            echo"No Record found";
        }?>
        </table>
   
  </div>

  <script>
    function toggleSubmenu(id) {
      const submenu = document.getElementById(id);
      submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
      submenu.parentElement.classList.toggle('open');
    }
  </script>
</body>
</html>