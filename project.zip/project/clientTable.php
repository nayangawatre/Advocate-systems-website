<!DOCTYPE html>
<html lang="en">
<head>
  <style>
  table {
      border: 5px solid #ccc;
      width: 100%;
      background-color: white;
      color: black;
  }

  th, td {
      padding: 10px;
      text-align: left;
  }

  th {
      background-color: white;
      color: black;
      width: 100px;
  }

  tbody tr:hover {
      background-color: gray;
      border-radius: 10px;
  }

  table {
      box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
  }
  </style>

  <meta charset="utf-8">
  <title>LAW FIRM</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="Law Firm" name="keywords">
  <meta content="Law Firm" name="description">
</head>
<body>

    <?php
    include "config.php";

    // Check if delete action is triggered
    if (isset($_GET['delete_id'])) {
        $delete_id = intval($_GET['delete_id']); // Sanitize input
        $delete_query = "DELETE FROM client_reg WHERE id = $delete_id";
        $delete_result = mysqli_query($con, $delete_query);

        if ($delete_result) {
            echo "<script>alert('Record deleted successfully!');</script>";
        } else {
            echo "<script>alert('Failed to delete the record.');</script>";
        }
    }

    // Fetch records
    $view = mysqli_query($con, "SELECT * FROM client_reg") or die(mysqli_error($con));
    ?> 

    <table class="table table-bordered table-hover">
        <thead>
            <h2>Contact for any query</h2>
            <tr>
                <th><b>Sr.No</b></th>
                <th><b>Client Name</b></th> 
                <th><b>Gender</b></th> 
                <th><b>Email address</b></th>
                <th><b>Mobile Number</b></th> 
                <th><b>Aadhar Number</b></th> 
                <th><b>Legal service type</b></th> 
                <th><b>Client Address</b></th> 
                <th><b>Action</b></th> 
            </tr>
        </thead> 
        <tbody> 
            <?php 
            $count = 0;
            while ($row = mysqli_fetch_array($view)) {
                extract($row); 
            ?> 
            <tr>
                <td><?php echo ++$count; ?></td> 
                <td><?php echo $row['clientname']; ?></td> 
                <td><?php echo $row['gender']; ?></td> 
                <td><?php echo $row['Email_id']; ?></td> 
                <td><?php echo $row['Mobile_no']; ?></td> 
                <td><?php echo $row['Aadhar_no']; ?></td> 
                <td><?php echo $row['Service_type']; ?></td> 
                <td><?php echo $row['clientaddress']; ?></td> 
                <td>
                    <a href="?delete_id=<?php echo $row['id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this record?');" 
                       class="btn btn-danger">Delete</a>
                </td>
            </tr>
            <?php } ?> 
        </tbody> 
    </table>
</body>
</html>