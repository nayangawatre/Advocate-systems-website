<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Registration</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom, #ffffff, #d3e2ef);
            color: #444;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #faf8f8;
            border: 1px solid #e0e0e0;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgb(153, 67, 67);
        }
        h2 {
            text-align: center;
            color: #7e4d4d;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #003366;
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #a66464;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: all 0.3s ease;
            background: #f4f8fc;
        }
        input:focus, select:focus, textarea:focus {
            border-color: #b36c6c;
            box-shadow: 0 0 8px rgba(0, 86, 179, 0.3);
            background: #ffffff;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #a06565;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #003366;
        }
        .form-footer {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .form-footer a {
            color: #0056b3;
            text-decoration: none;
            font-weight: bold;
        }
        .form-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        include 'config.php';
        if (isset($_POST['submit'])) {
            extract($_POST);
            
            // Corrected query: Use form field names for database insertion
            $add = mysqli_query($con, "INSERT INTO client_reg (clientname, gender, Email_id, Mobile_no, Aadhar_no, Service_type,password, clientaddress) 
            VALUES ('$clientname', '$gender', '$email', '$mobileno', '$aadharno', '$legalservice', '$password','$clientaddress')")
            or die(mysqli_error($con));

            if ($add) {
                echo "<script>";
        echo "window.alert('Data Add Successfully......!');";
        echo "</script>";
            } else {
                echo "<script>";
                echo "window.alert('Data Not Add......!');";
                echo "</script>";
            }
        }
        ?>
        <h2>Client Registration Form</h2>
        <form action="client_reg.php" method="POST">
            <div class="form-group">
                <label for="clientname">Full Name:</label>
                <input type="text" id="clientname" name="clientname" placeholder="Enter your full name" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="" disabled selected>-- Select Gender --</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="mobileno">Mobile Number:</label>
                <input type="tel" id="mobileno" name="mobileno" placeholder="Enter your mobile number" required>
            </div>
            <div class="form-group">
                <label for="aadharno">Aadhar Number:</label>
                <input type="text" id="aadharno" name="aadharno" placeholder="Enter your Aadhar number" required>
            </div>
            <div class="form-group">
                <label for="legalservice">Legal Service Type:</label>
                <select id="legalservice" name="legalservice" required>
                    <option value="" disabled selected>-- Select Service Type --</option>
                    <option value="civil">Civil</option>
                    <option value="criminal">Criminal</option>
                    <option value="family">Family</option>
                    <option value="corporate">Corporate</option>
                    <option value="business">Business</option>
                    <option value="others">Others</option>
                </select>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="set your password" required>
            </div>
            <div class="form-group">
                <label for="clientaddress">Address:</label>
                <textarea id="clientaddress" name="clientaddress" rows="3" placeholder="Enter your address" required></textarea>
            </div>
            <button type="submit" name="submit">Register</button>
        </form>
        <div class="form-footer">
            <p>Already registered? <a href="login.html">Login here</a></p>
        </div>
    </div>
</body>
</html>
