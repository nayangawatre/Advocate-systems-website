<?php 
   $con=mysqli_connect("localhost","root","","cpe")or die(mysqli_error($con));
   if(!$con)
   {
   // echo "Database is connected now";
  // }
   //else{
    die("Error". mysqli_connect_error());
   }
?>


