<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Register As An Advocate</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Advocate Registration" name="keywords">
    <meta content="Advocate Registration" name="description">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-top: 5px solid #C39B72;
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
            color: #C39B72;
        }
        .form-title h1 {
            margin: 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
            color: #C39B72;
        }
        .form-control, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            color: #333;
            background-color: #f9f9f9;
        }
        .form-control:focus, select:focus {
            border-color: #C39B72;
            box-shadow: 0 0 5px rgba(195, 155, 114, 0.5);
        }
        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: #C39B72;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #A07853;
        }
        .file-input {
            border: 1px solid #ccc;
            padding: 6px;
            font-size: 14px;
            border-radius: 5px;
            width: 100%;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>

    <div class="container-fluid py-5">
        <div class="container mt-4">
        
<?php
include "config.php";

if (isset($_POST['submit'])) {
    // Extract form data
    

    // File upload handling
    $profileimage = '';
    $target_dir = "uploads/"; // Directory to store uploaded files

    // Ensure the 'uploads/' directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true); // Create the directory if it doesn't exist
    }

    $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a valid image
    if (getimagesize($_FILES["profile_image"]["tmp_name"]) === false) {
        echo "<script>window.alert('File is not an image.');</script>";
        $uploadOk = 0;
    }

    // Check file size (max 5MB)
    if ($_FILES["profile_image"]["size"] > 5000000) {
        echo "<script>window.alert('Sorry, your file is too large.');</script>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if (!in_array($imageFileType, ["jpg", "png", "jpeg", "gif"])) {
        echo "<script>window.alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');</script>";
        $uploadOk = 0;
    }

    // Upload file if validations pass
    if ($uploadOk == 0) {
        echo "<script>window.alert('Sorry, your file was not uploaded.');</script>";
    } else {
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
            $profileimage = $target_file; // Save the file path
            echo "<script>window.alert('File uploaded successfully.');</script>";
        } else {
            echo "<script>window.alert('Sorry, there was an error uploading your file.');</script>";
        }
    }

    // Insert data into the database
    $add = mysqli_query($con, "INSERT INTO advocate(profileimage, advname, email, mobileno, advaddress, city, experienceyear, practicearea, court,password) 
    VALUES ('$profileimage', '$advname', '$email', '$mobileno', '$advaddress', '$city', '$experienceyear', '$practicearea', '$court',$password)");

    if ($add) {
        echo "<script>
        alert('Data Added Successfully......!');
        </script>";
    } else {
        echo "<script>
        alert('Data Not Add......!');
        </script>";
    }
}
?>

        <div class="form-title">
            <h1>Register As An Advocate</h1>
        </div>

        <form action="advocateReg.php" method="POST" enctype="multipart/form-data">
            <!-- Profile Image -->
            <div class="form-group">
                <label for="profile_image">Profile Image:</label>
                <input type="file" name="profile_image" id="profile_image" class="file-input" required>
            </div>

            <!-- Full Name -->
            <div class="form-group">
                <label for="advname">Full Name:</label>
                <input type="text" name="advname" id="advname" class="form-control" required>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>

            <!-- Mobile Number -->
            <div class="form-group">
                <label for="mobileno">Mobile No:</label>
                <input type="text" name="mobileno" id="mobileno" class="form-control" required>
            </div>

            <!-- Address -->
            <div class="form-group">
                <label for="advaddress">Address:</label>
                <input type="text" name="advaddress" id="advaddress" class="form-control" required>
            </div>

            <!-- City -->
            <div class="form-group">
                <label for="city">City:</label>
                <input type="text" name="city" id="city" class="form-control" required>
            </div>

            <!-- Experience -->
            <div class="form-group">
                <label for="experienceyear">Experience (Years):</label>
                <input type="number" name="experienceyear" id="experienceyear" class="form-control" required>
            </div>

            <!-- Practice Area -->
            <div class="form-group">
                <label for="practicearea">Practice Area:</label>
                <select name="practicearea" id="practicearea" class="form-control" required>
                    <option value="" disabled selected>Select a Practice Area</option>
                    <option value="Civil">Civil</option>
                    <option value="Criminal">Criminal</option>
                    <option value="Corporate">Corporate</option>
                    <option value="Family">Family</option>
                    <option value="Business">Business</option>
                </select>
            </div>

            <!-- Court -->
            <div class="form-group">
                <label for="court">Court:</label>
                <input type="text" name="court" id="court" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="court">password:</label>
                <input type="text" name="password" id="password" class="form-control" required>
            </div>

            <!-- Submit Button -->
            <div class="form-group">
                <button type="submit" name="submit" class="btn-submit">Register Advocate</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
