<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif, sans-serif;
      font-weight: 100;
      font-weight: 100;
      


      margin: 0;
      padding: 0;
      display: flex;
      background-color: #f4f4f9;
    }

    .sidebar {
      width: 20%;
      background: linear-gradient(180deg, #333, #555);
      color: white;
      padding: 20px;
      height: 100vh;
      box-shadow: 2px 0 5px rgba(189, 35, 35, 0.1);
    }

    .sidebar h2 {
      font-size: 24px;
      margin-bottom: 20px;
      text-align: center;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin: 15px 0;
      font-size: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 10px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .sidebar ul li:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
    }

    .submenu {
      display: none;
      margin-left: 20px;
    }

    .submenu li {
      margin: 10px 0;
      font-size: 16px;
    }

    .main-content {
      width: 80%;
      padding: 20px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .header input[type="text"] {
      padding: 10px;
      font-size: 16px;
      width: 350px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header button {
      padding: 10px 20px;
      font-size: 16px;
      color: white;
      background-color: #B49C73;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .header button:hover {
      background-color: #B49C73;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .card {
      background: linear-gradient(145deg, #ffffff, #e6e6e6);
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1), -5px -5px 10px rgba(255, 255, 255, 0.5);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .card button {
      width: 100%;
      height: 70px;
      font-size: 20px;
      font-weight: bold;
      background: linear-gradient(90deg, #B49C73, #B49C73);
      color: white;
      border: none;
      left
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .card button:hover {
      background: linear-gradient(90deg, #B49C73, #B49C73);
    }

    .arrow {
      transition: transform 0.3s;
    }

    .sidebar ul li.open .arrow {
      transform: rotate(180deg);
    }
  </style>
</head>
<link href="css/style.css" rel="stylesheet">
<body>
    
  <div class="sidebar">
  <?php
  session_start();
  echo "welocome  ".$_SESSION['email_id'];
  ?>
    <h2 class="card"> Client Dashboard</h2>

    <ul>

    <a href="adv_view.php" class="card button">view Advocate</a>

    <a href="appointForm.php" class="card button">apointment schedule</a>

    <a href="case_status.php" class="card button">Case Status And Updation</a>

    <a href="login.php" class="card button">Upload Case Documents</a>

    <a href="login.php" class="card button">upload review</a>
    
      
     
     

     
    


  </div>
  <div class="main-content">
  <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 bg-secondary d-none d-lg-block">
                <a href="index.html" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                </a>
            </div>
            <div class="col-lg-9">
               
                <nav class="navbar navbar-expand-lg bg-white navbar-light p-0">
                    <a href="index.html" class="navbar-brand d-block d-lg-none">
                        <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="chome.php" class="nav-item nav-link active">Home</a>
                            <a href="cabout.php" class="nav-item nav-link">About</a>
                            
                            <a href="adv_view.php" class="nav-item nav-link">Attorneys</a>
                            <a href="ccontact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <a href="" class="btn btn-primary mr-3 d-none d-lg-block">CLIENT</a>
                        <a href="login.php" class="btn btn-primary mr-3 d-none d-lg-block">LOGOUT</a>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <div class="container-fluid p-0 mb-5 pb-5">
        <div id="header-carousel" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item position-relative active" style="height: 100vh; min-height: 400px;">
                    <img class="position-absolute w-100 h-100" src="img/carousel-1.jpg" style="object-fit: cover;">
                   
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Best Law Firm</h4>
                            <h3 class="display-3 text-capitalize text-white mb-4">Our fighting Is for<br> your justice</br></h3>
                            <a href="appoint.html" class="btn btn-primary py-3 px-5 mt-2" href="#">Get An Appointment</a>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-5">
                    <img class="img-fluid rounded" src="img/about.jpg" alt="">
                </div>
                <div class="col-lg-7 mt-4 mt-lg-0">
                    <h2 class="position-relative text-center bg-white text-primary rounded p-3 mt-4 mb-4 d-none d-lg-block" style="width: 350px; margin-left: -205px;">25 Years Experience</h2>
                    <h6 class="text-uppercase">Learn About Us</h6>
                    <h1 class="mb-4">We Provide Reliable And Effective Legal Services</h1>
                    <p>With 25 years of experience, we provide reliable legal services to help you with all your legal needs. Our team specializes in areas like business law, family issues, criminal cases, and disputes. We are here to guide you, solve your problems, and get the best results for you. Click below to find out more about how we can help.</p>
                    <a href="" class="btn btn-primary mt-2">Learn More</a>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-6" style="min-height: 500px;">
                    <div class="position-relative h-100 rounded overflow-hidden">
                        <img class="position-absolute w-100 h-100" src="img/feature.jpg" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 pt-5 pb-lg-5">
                    <div class="feature-text bg-white rounded p-lg-5">
                        <h6 class="text-uppercase">Our Features</h6>
                        <h1 class="mb-4">Why Choose Us</h1>
                        <div class="d-flex mb-4">
                            <div class="btn-primary btn-lg-square px-3" style="border-radius: 50px;">
                                <h5 class="text-secondary m-0">01</h5>
                            </div>
                            <div class="ml-4">
                                <h5>Best Law Practices</h5>
                                <p class="m-0">We deliver exceptional legal services to the highest professional standards. Our team of experts ensures that every case is handled with diligence, precision, and a deep understanding of the law, offering solutions tailored to your needs.
                                </p>
                            </div>
                        </div>
                        <div class="d-flex mb-4">
                            <div class="btn-primary btn-lg-square px-3" style="border-radius: 50px;">
                                <h5 class="text-secondary m-0">02</h5>
                            </div>
                            <div class="ml-4">
                                <h5>Efficiency & Trust</h5>
                                <p class="m-0">Efficiency and trust are the foundation of our practice. We prioritize clear communication and transparency ensuring that our clients feel confident and supported throughout their legal journey.</p>
                            </div>
                        </div>
                        <div class="d-flex mb-4">
                            <div class="btn-primary btn-lg-square px-3" style="border-radius: 50px;">
                                <h5 class="text-secondary m-0">03</h5>
                            </div>
                            <div class="ml-4">
                                <h5>Results You Deserve</h5>
                                <p class="m-0">We are dedicated to achieving the best possible outcomes for our clients. By combining our expertise and a commitment to excellence, Your success is our priority</p>
                            </div>
                        </div>
                        <div class="d-flex mb-4">
                            <div class="btn-primary btn-lg-square px-3" style="border-radius: 50px;">
                                <h5 class="text-secondary m-0">04</h5>
                            </div>
                            <div class="ml-4">
                                <h5>Efficient And Timely Services</h5>
                                <p class="m-0">We understand the importance of time in legal matters. Our team is committed to addressing your concerns quickly, meeting deadlines, and providing timely solutions without compromising quality.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cards">
      <!-- Total Lawyers -->
      <div class="card">
        
        <button> <a href="advRegTable.php">total Lawyers</a> </button>
      </div>

      <!-- Total Clients -->
      <div class="card">
        <button><a href="clientTable.php">Total Clients</a></button>
      </div>

      <!-- Total Cases -->
      <div class="card">
        <button> <a href="caseRegTable.php">Total Cases</a></button>
      </div>
    </div>
  </div>
  

  <script>
    function toggleSubmenu(id) {
      const submenu = document.getElementById(id);
      submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
      submenu.parentElement.classList.toggle('open');
    }
  </script>
</body>
</html>