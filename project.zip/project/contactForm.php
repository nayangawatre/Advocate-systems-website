<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>LAW FIRM</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Law Firm" name="keywords">
    <meta content="Law Firm" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@300;500;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>    

    <div class="container-fluid py-5">
        <div class="container mt-4">
            <?php
            include "config.php";

            if (isset($_POST['submit'])) {
                // Sanitize and retrieve form data
                $client_name = mysqli_real_escape_string($con, $_POST['client_name']);
                $client_email = mysqli_real_escape_string($con, $_POST['client_email']);
                $messagetoadv = mysqli_real_escape_string($con, $_POST['messagetoadv']);

                // Insert data into the database
                $query = "INSERT INTO contact (client_name, client_email, messagetoadv) VALUES ('$client_name', '$client_email', '$messagetoadv')";
                $add = mysqli_query($con, $query) or die("SQL Error: " . mysqli_error($con));

                if ($add) {
                    echo "<script>alert('Data Added Successfully!');</script>";
                } else {
                    echo "<script>alert('Data Not Added! Please try again.');</script>";
                }
            }
            ?>

            <div class="text-center pb-2">
                <h6 class="text-uppercase">Contact Us</h6>
                <h1 class="mb-4">Contact For Any Query</h1>
            </div>
            <div class="row">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="contact-form">
                        <div id="success"></div>
                        <!-- Add 'action' and 'method' attributes -->
                        <form name="sentMessage" id="contactForm" action="" method="POST" novalidate="novalidate">
                            <div class="form-row">
                                <div class="col-sm-6 control-group">
                                    <input type="text" class="form-control p-4" id="name" name="client_name" placeholder="Your Name" required="required" data-validation-required-message="Please enter your name" />
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="col-sm-6 control-group">
                                    <input type="email" class="form-control p-4" id="email" name="client_email" placeholder="Your Email" required="required" data-validation-required-message="Please enter your email" />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control p-4" rows="6" id="message" name="messagetoadv" placeholder="Message" required="required" data-validation-required-message="Please enter your message"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div>
                                <button class="btn btn-primary btn-block" type="submit" name="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
