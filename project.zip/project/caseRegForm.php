<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Case Registration</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Case Registration" name="keywords">
    <meta content="Case Registration" name="description">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-top: 5px solid #C39B72;
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
            color: #C39B72;
        }
        .form-title h1 {
            margin: 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
            color: #C39B72;
        }
        .form-control, select, input[type="date"] {
            width: 100%;
            padding: 10px;  /* Consistent padding for uniform size */
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            color: #333;
            background-color: #f9f9f9;
        }
        .form-control:focus, select:focus, input[type="date"]:focus {
            border-color: #C39B72;
            box-shadow: 0 0 5px rgba(195, 155, 114, 0.5);
        }
        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: #C39B72;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #A07853;
        }
    </style>

</head>
<body>

<<div class="container-fluid py-5">
         <div class="container mt-4">
         <?php
include "config.php";
if (isset($_POST['submit'])) {
    extract($_POST);
    
    // Corrected query: Use single quotes for values
    $add = mysqli_query($con, "INSERT INTO legal_case (caseid, casename, casecategory, advocatename, clientname, caseregdate) 
VALUES ('$caseid', '$casename', '$casecategory', '$advocatename', '$clientname', '$caseregistrationdate')") 
or die(mysqli_error($con));

    if ($add) {
        echo "<script>";
        echo "window.alert('Data Add Successfully......!');";
        echo "</script>";
    } else {
        echo "<script>";
        echo "window.alert('Data Not Add......!');";
        echo "</script>";
    }
}
?>
<div class="container-fluid py-5">
        <div class="container py-5">
        <div class="form-title">
            <h1>Case Registration Form</h1>
        </div>

        <form action="caseRegForm.php" method="POST">
            <!-- Case ID -->
            <div class="form-group">
                <label for="caseid">Case ID:</label>
                <input type="text" name="caseid" id="caseid" class="form-control" required>
            </div>

            <!-- Case Name -->
            <div class="form-group">
                <label for="casename">Case Name:</label>
                <input type="text" name="casename" id="casename" class="form-control" required>
            </div>

            <!-- Case Category -->
            <div class="form-group">
                <label for="casecategory">Case Category:</label>
                <select name="casecategory" id="casecategory" class="form-control" required>
                    <option value="" disabled selected>Select Category</option>
                    <option value="Civil">Civil</option>
                    <option value="Criminal">Criminal</option>
                    <option value="Corporate">Corporate</option>
                    <option value="Family">Family</option>
                    <option value="Business">Business</option>
                </select>
            </div>

            <!-- Advocate Name -->
            <div class="form-group">
                <label for="advocatename">Advocate Name:</label>
                <input type="text" name="advocatename" id="advocatename" class="form-control" required>
            </div>

            <!-- Client Name -->
            <div class="form-group">
                <label for="clientname">Client Name:</label>
                <input type="text" name="clientname" id="clientname" class="form-control" required>
            </div>

            <!-- Case Registration Date -->
            <div class="form-group">
                <label for="caseregistrationdate">Case Registration Date:</label>
                <input type="date" name="caseregistrationdate" id="caseregistrationdate" class="form-control" required>
            </div>

            <!-- Submit Button -->
            <div class="form-group">
                <button type="submit" name="submit" class="btn-submit">Register Case</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
