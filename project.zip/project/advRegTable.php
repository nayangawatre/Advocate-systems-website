<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    table {
        border: 5px solid #ccc;
        width: 100%;
        background-color: white;
        color: black;
    }

    th, td {
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: white;
        color: black;
        width: 100px;
    }

    tbody tr:hover {
        background-color: gray;
        border-radius: 10px;
    }

    table {
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }
  </style>

  <meta charset="utf-8">
  <title>LAW FIRM</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="Law Firm" name="keywords">
  <meta content="Law Firm" name="description">
</head>
<body>

    <?php
    include "config.php";

    // Check if delete action is triggered
    if (isset($_GET['delete_id'])) {
        $delete_id = intval($_GET['delete_id']); // Sanitize input
        $delete_query = "DELETE FROM advocate WHERE id = $delete_id";
        $delete_result = mysqli_query($con, $delete_query);

        if ($delete_result) {
            echo "<script>alert('Advocate Record deleted successfully!');</script>";
        } else {
            echo "<script>alert('Failed to delete the advocate record.');</script>";
        }
    }

    // Fetch records
    $view = mysqli_query($con, "SELECT * FROM advocate") or die(mysqli_error($con));
    ?> 

    <table class="table table-bordered table-hover">
        <thead>
            <h2>Advocate Registration</h2>
            <tr>
                <th><b>Sr.No</b></th>
                <th><b>Profile Image</b></th> 
                <th><b>Advocate Name</b></th> 
                <th><b>Advocate Email </b></th> 
                <th><b>Advocate Mobile No</b></th> 
                <th><b>Advocate Address</b></th>
                <th><b>Advocate City</b></th>
                <th><b>Advocate Experience Year</b></th>
                <th><b>Advocate Practice Area</b></th>
                <th><b>Advocate Court</b></th>
                <th><b>Action</b></th> 
            </tr>
        </thead> 
        <tbody> 
            <?php 
            $count = 0;
            while ($row = mysqli_fetch_array($view)) {
                extract($row); 
            ?> 
            <tr>
                <td><?php echo ++$count; ?></td> 
                <td><img src="<?php echo $row['profileimage']; ?>" alt="Profile Image" width="100" height="100"></td> 
                <td><?php echo $row['advname']; ?></td> 
                <td><?php echo $row['email']; ?></td> 
                <td><?php echo $row['mobileno']; ?></td> 
                <td><?php echo $row['advaddress']; ?></td> 
                <td><?php echo $row['city']; ?></td> 
                <td><?php echo $row['experienceyear']; ?></td> 
                <td><?php echo $row['practicearea']; ?></td> 
                <td><?php echo $row['court']; ?></td> 
                <td>
                    <a href="?delete_id=<?php echo $row['id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this record?');" 
                       class="btn btn-danger">Delete</a>
                </td>
            </tr>
            <?php } ?> 
        </tbody> 
    </table>
</body>
</html>

