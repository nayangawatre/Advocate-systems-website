<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif, sans-serif;
      font-weight: 100;
      font-weight: 100;
      


      margin: 0;
      padding: 0;
      display: flex;
      background-color: #f4f4f9;
    }

    .sidebar {
      width: 20%;
      background: linear-gradient(180deg, #333, #555);
      color: white;
      padding: 20px;
      height: 100vh;
      box-shadow: 2px 0 5px rgba(189, 35, 35, 0.1);
    }

    .sidebar h2 {
      font-size: 24px;
      margin-bottom: 20px;
      text-align: center;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin: 15px 0;
      font-size: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 10px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .sidebar ul li:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
    }

    .submenu {
      display: none;
      margin-left: 20px;
    }

    .submenu li {
      margin: 10px 0;
      font-size: 16px;
    }

    .main-content {
      width: 80%;
      padding: 20px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .header input[type="text"] {
      padding: 10px;
      font-size: 16px;
      width: 350px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header button {
      padding: 10px 20px;
      font-size: 16px;
      color: white;
      background-color: #B49C73;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .header button:hover {
      background-color: #B49C73;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .card {
      background: linear-gradient(145deg, #ffffff, #e6e6e6);
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1), -5px -5px 10px rgba(255, 255, 255, 0.5);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

 

    .card button:hover {
      background: linear-gradient(90deg, #B49C73, #B49C73);
    }

    .arrow {
      transition: transform 0.3s;
    }

    .sidebar ul li.open .arrow {
      transform: rotate(180deg);
    }
  </style>
</head>
<link href="css/style.css" rel="stylesheet">
<body>
    
  <div class="sidebar">
    <h2 class="card"> Client Dashboard</h2>
    <ul>

    <a href="adv_view.php" class="card button">view Advocate</a>

    <a href="appointForm.php" class="card button">apointment schedule</a>

    <a href="login.php" class="card button">Case Status And Updation</a>

    <a href="login.php" class="card button">Upload Case Documents</a>

    <a href="login.php" class="card button">upload review</a>
    
      
    <?php
    include "config.php";
    if (isset($_POST['submit'])) {
        extract($_POST);
        
        // Corrected query: Use single quotes for values
        
    $add = mysqli_query($con, "INSERT INTO appointment (client_name, client_email, appointdate, appointtime, legalservice) 
    VALUES ('$client_name', '$client_email', '$appointdate', '$appointtime', '$legalservice')") 
    or die(mysqli_error($con));
    
        
        if ($add) {
            echo "<script>";
            echo "window.alert('Data Add Successfully......!');";
            echo "</script>";
        } else {
            echo "<script>";
            echo "window.alert('Data Not Add......!');";
            echo "</script>";
        }
    }
    ?>
     
     

     
    


  </div>
  <div class="main-content">
  <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 bg-secondary d-none d-lg-block">
                <a href="index.html" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                </a>
            </div>
            <div class="col-lg-9">
               
                <nav class="navbar navbar-expand-lg bg-white navbar-light p-0">
                    <a href="index.html" class="navbar-brand d-block d-lg-none">
                        <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="chome.php" class="nav-item nav-link active">Home</a>
                            <a href="about.php" class="nav-item nav-link">About</a>
                        
                            <a href="adv_view.php" class="nav-item nav-link">Attorneys</a>
                            <a href="ccontact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <a href="" class="btn btn-primary mr-3 d-none d-lg-block">CLIENT</a>
                        <a href="login.php" class="btn btn-primary mr-3 d-none d-lg-block">LOGOUT</a>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
    
        <div class="container py-5">
            <div class="bg-appointment rounded">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-lg-6 py-5">
                        <div class="rounded p-5 my-5" style="background: rgba(55, 55, 63, .7);">
                            <h1 class="text-center text-white mb-4">Get An Appointment</h1>
<form action="" method="post">
    <div class="form-group">
        <input type="text" name="client_name" class="form-control border-0 p-4" placeholder="Your Name" required="required" />
    </div>
    <div class="form-group">
        <input type="email" name="client_email" class="form-control border-0 p-4" placeholder="Your Email" required="required" />
    </div>
    <div class="form-row">
        <div class="col-6">
            <div class="form-group">
                <div class="date" id="date" data-target-input="nearest">
                    <input type="date" name="appointdate" class="form-control border-0 p-4 datetimepicker-input" placeholder="Select Date" data-target="#date" data-toggle="datetimepicker" required="required"/>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <div class="time" id="time" data-target-input="nearest">
                    <input type="time" name="appointtime" class="form-control border-0 p-4 datetimepicker-input" placeholder="Select Time" data-target="#time" data-toggle="datetimepicker" required="required"/>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group">
    <select name="legalservice" class="custom-select border-0 px-4" style="height: 47px;" required="required">
            <option selected disabled>Select Legal Service</option>
            <option value="Civil">Civil</option>
            <option value="Corporate">Corporate</option>
            <option value="Family">Family</option>
            <option value="Business">Business</option>
            <option value="Criminal">Criminal</option>
        </select>
    </div>
    <div>
        <button class="btn btn-primary btn-block border-0 py-3" type="submit" name="submit">Get An Appointment</button>
    </div>
</form>
</div>
</div>
</div>
</div>
</div>
</body>
</html>