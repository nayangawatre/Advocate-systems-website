<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <?php
  
  require_once 'config.php';
  $sql ="SELECT * FROM advocate";
  $all_product = $con->query($sql);

  ?>
  <style>
    body {
      font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif, sans-serif;
      font-weight: 100;
      font-weight: 100;
      


      margin: 0;
      padding: 0;
      display: flex;
      background-color: #f4f4f9;
    }

    .sidebar {
      width: 20%;
      background: linear-gradient(180deg, #333, #555);
      color: white;
      padding: 20px;
      height: 100vh;
      box-shadow: 2px 0 5px rgba(189, 35, 35, 0.1);
    }

    .sidebar h2 {
      font-size: 24px;
      margin-bottom: 20px;
      text-align: center;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin: 15px 0;
      font-size: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 10px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .sidebar ul li:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
    }

    .submenu {
      display: none;
      margin-left: 20px;
    }

    .submenu li {
      margin: 10px 0;
      font-size: 16px;
    }

    .main-content {
      width: 80%;
      padding: 20px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .header input[type="text"] {
      padding: 10px;
      font-size: 16px;
      width: 350px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .header button {
      padding: 10px 20px;
      font-size: 16px;
      color: white;
      background-color: #B49C73;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .header button:hover {
      background-color: #B49C73;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .card {
      background: linear-gradient(145deg, #ffffff, #e6e6e6);
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1), -5px -5px 10px rgba(255, 255, 255, 0.5);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }
  

    .card button {
      width: 100%;
      height: 70px;
      font-size: 20px;
      font-weight: bold;
      background: linear-gradient(90deg, #B49C73, #B49C73);
      color: white;
      border: none;
      left
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .card button:hover {
      background: linear-gradient(90deg, #B49C73, #B49C73);
    }

    .arrow {
      transition: transform 0.3s;
    }
    .see_more{

    }

    .sidebar ul li.open .arrow {
      transform: rotate(180deg);
    }
  </style>
</head>
<link href="css/style.css" rel="stylesheet">
<body>
    
  <div class="sidebar">
    <h2 class="card"> Client Dashboard</h2>
    <ul>

    <a href="adv_view.php" class="card button">view Advocate</a>

    <a href="appointForm.php" class="card button">apointment schedule</a>

    <a href="case_status.php" class="card button">Case Status And Updation</a>

    <a href="login.php" class="card button">Upload Case Documents</a>

    <a href="login.php" class="card button">upload review</a>
    
      
     
     

     
    


  </div>
  <div class="main-content">
  <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 bg-secondary d-none d-lg-block">
                <a href="index.html" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                </a>
            </div>
            <div class="col-lg-9">
               
                <nav class="navbar navbar-expand-lg bg-white navbar-light p-0">
                    <a href="index.html" class="navbar-brand d-block d-lg-none">
                        <h1 class="m-0 display-15 text-primary text-uppercase">Law Firm</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="chome.php" class="nav-item nav-link active">Home</a>
                            <a href="about.php" class="nav-item nav-link">About</a>
                           
                            <a href="team.php" class="nav-item nav-link">Attorneys</a>
                            <a href="ccontact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <a href="" class="btn btn-primary mr-3 d-none d-lg-block">CLIENT</a>
                        <a href="login.php" class="btn btn-primary mr-3 d-none d-lg-block">LOGOUT</a>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-page-header" style="margin-bottom: 90px;">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-3 text-white text-uppercase">Attorney</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="chome.php">Home</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Attorney</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Team Start -->
    <?php 
    while($row=mysqli_fetch_assoc($all_product)){?>
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="text-center pb-2">
                <h6 class="text-uppercase">Our Attorneys</h6>
                <h1 class="mb-4">Meet Our Attorneys</h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="bg-primary rounded" style="height: 200px;"></div>
                    <div class="owl-carousel team-carousel position-relative" style="margin-top: -97px; padding: 0 30px;">
                    <div class="team-item text-center bg-white rounded overflow-hidden pt-4">
                      <div class="image">
                        <img src="<?php echo $row["profileimage"];?>" alt="">
                      </div>
                      <div class="caption">
                        <p class="Attorney_Name"><?php echo $row["profileimage"];?></p>
                        <p class="email"><?php echo $row["email"];?></p>
                        <p class="mobileno"><?php echo $row["mobileno"];?></p>
                        <p class="city"><?php echo $row["city"];?></p>
                        <p class="addresss"><?php echo $row["address"];?></p>
                        <p class="experince"><?php echo $row["experinceyear"];?></p>
                      
                        <p class="Practice_Area"><?php echo $row["practicearea"];?></p>
                      </div>
                      <<a href="login.php" class="btn btn-primary mr-3 d-none d-lg-block">Gat an appointment</a>


                    </div>

                        
                    
                    
                   
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
</body>
</html>