<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap" rel="stylesheet">

     <!-- Font Awesome -->
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

      <!-- Material Icons Link -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<?php
include('config.php');
session_start();

if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $psw=$_POST['password'];
    $query="SELECT * FROM client_reg WHERE Email_id='$email' && Password='$psw'";
    $data=mysqli_query($con,$query);
    $totle=mysqli_num_rows($data);
    if($totle==1){
        $_SESSION['email_id']=$email;
        header('location:chome.php');
    }
    
    else{
        echo"Login failed";
    }
}
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $psw=$_POST['password'];
    $query="SELECT * FROM admin WHERE username='$email' && password='$psw'";
    $data=mysqli_query($con,$query);
    $totle=mysqli_num_rows($data);
    if($totle==1){
        $_SESSION['email_id']=$email;
        header('location:dashboard.html');
    }
    
    else{
        echo"Login failed";
    }
}
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $psw=$_POST['password'];
    $query="SELECT * FROM advocate WHERE email='$email' && password='$psw'";
    $data=mysqli_query($con,$query);
    $totle=mysqli_num_rows($data);
    if($totle==1){
        $_SESSION['email_id']=$email;
        header('location:ahome.php');
    }
    
    else{
        echo"Login failed";
    }
}

?>
<body>
    <div class="login-container">
       
        <h2>Login</h2>
        <form action="" method="post">  <div class="input-group">
                <div class="form-group">
                    <input type="text" class="form-control border-0 p-4" name="email" placeholder="email" required="required" />
                </div>
            </div>
            <div class="input-group">
                <div class="form-group">
                    <input type="text" class="form-control border-0 p-4" name="password" placeholder="password" required="required" />
                </div>
            </div>
            <input class="btn btn-primary btn-block border-0 py-5" name="submit" type="submit" value="Login"></input>
            <p class="signup-link">Don't have an account?  <a href="clientReg.php" class="signup-link">client register</a><br><br>
                        <a href="advocateReg.php" class="signup-link">advocate register</a><br><br>
                        <a href="login.php" class="signup-link">admin</a> </p> 
           
            </form>
    </div>
</body>

</html>